﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class ProBankingSystem
    {
        static void Main(string[] args)
        {
            double balance = 1000.00; // Initial balance
            bool exit = false;

            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("Simple Banking System");
                Console.WriteLine("1. View Balance");
                Console.WriteLine("2. Deposit Money");
                Console.WriteLine("3. Withdraw Money");
                Console.WriteLine("4. Exit");
                Console.Write("Select an option: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ViewBalance(balance);
                        break;
                    case "2":
                        balance = DepositMoney(balance);
                        break;
                    case "3":
                        balance = WithdrawMoney(balance);
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid option, please try again.");
                        break;
                }
            }
        }

        static void ViewBalance(double balance)
        {
            Console.Clear();
            Console.WriteLine($"Your current balance is: ${balance}");
            Console.WriteLine("\nPress any key to go back...");
            Console.ReadKey();
        }

        static double DepositMoney(double balance)
        {
            Console.Clear();
            Console.Write("Enter the amount to deposit: ");
            double depositAmount = Convert.ToDouble(Console.ReadLine());
            balance += depositAmount;
            Console.WriteLine($"You have deposited ${depositAmount}. Your new balance is ${balance}.");
            Console.WriteLine("\nPress any key to go back...");
            Console.ReadKey();
            return balance;
        }

        static double WithdrawMoney(double balance)
        {
            Console.Clear();
            Console.Write("Enter the amount to withdraw: ");
            double withdrawAmount = Convert.ToDouble(Console.ReadLine());

            if (withdrawAmount > balance)
            {
                Console.WriteLine("Insufficient funds. Please try again.");
            }
            else
            {
                balance -= withdrawAmount;
                Console.WriteLine($"You have withdrawn ${withdrawAmount}. Your new balance is ${balance}.");
            }

            Console.WriteLine("\nPress any key to go back...");
            Console.ReadKey();
            return balance;
        }
    }

}
