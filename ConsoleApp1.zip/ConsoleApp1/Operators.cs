﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Operators
    {
        static void Main(string[] args)
        {
            int x = 23;

            Console.WriteLine(x > 2 &&  x < 21);
            Console.ReadLine();
                    
        
        }
    }
}
