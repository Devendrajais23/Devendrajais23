﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class IfElse
    {

        public static void Main(string[] args)
        {
            int x = 50;
            int y = 20;
            if (x >= y)
            {
                Console.WriteLine("20 say jayda 50 hai");
                
            }
            else
            { 
                   Console.WriteLine("50 say chota 20 hai");
               
            }
            Console.ReadLine();
        }

    }
}
