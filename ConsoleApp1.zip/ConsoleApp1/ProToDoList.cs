﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class ProToDoList
    {
        static void Main(string[] args)
        {
            List<string> toDoList = new List<string>();
            bool exit = false;

            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("To-Do List Application");
                Console.WriteLine("1. View Tasks");
                Console.WriteLine("2. Add Task");
                Console.WriteLine("3. Remove Task");
                Console.WriteLine("4. Mark Task as Done");
                Console.WriteLine("5. Exit");
                Console.Write("Choose an option: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ViewTasks(toDoList);
                        break;
                    case "2":
                        AddTask(toDoList);
                        break;
                    case "3":
                        RemoveTask(toDoList);
                        break;
                    case "4":
                        MarkTaskDone(toDoList);
                        break;
                    case "5":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        Console.ReadLine();
                        break;
                }
            }
        }

        static void ViewTasks(List<string> tasks)
        {
            Console.Clear();
            Console.WriteLine("To-Do List:");
            if (tasks.Count == 0)
            {
                Console.WriteLine("No tasks found.");
            }
            else
            {
                for (int i = 0; i < tasks.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {tasks[i]}");
                }
            }
            Console.WriteLine("\nPress any key to go back...");
            Console.ReadKey();
        }

        static void AddTask(List<string> tasks)
        {
            Console.Clear();
            Console.Write("Enter the task description: ");
            string task = Console.ReadLine();
            tasks.Add(task);
            Console.WriteLine("Task added!");
            Console.WriteLine("\nPress any key to go back...");
            Console.ReadKey();
        }

        static void RemoveTask(List<string> tasks)
        {
            Console.Clear();
            ViewTasks(tasks);
            if (tasks.Count > 0)
            {
                Console.Write("Enter the number of the task to remove: ");
                int index = Convert.ToInt32(Console.ReadLine()) - 1;
                if (index >= 0 && index < tasks.Count)
                {
                    tasks.RemoveAt(index);
                    Console.WriteLine("Task removed!");
                }
                else
                {
                    Console.WriteLine("Invalid task number.");
                }
            }
            Console.WriteLine("\nPress any key to go back...");
            Console.ReadKey();
        }

        static void MarkTaskDone(List<string> tasks)
        {
            Console.Clear();
            ViewTasks(tasks);
            if (tasks.Count > 0)
            {
                Console.Write("Enter the number of the task to mark as done: ");
                int index = Convert.ToInt32(Console.ReadLine()) - 1;
                if (index >= 0 && index < tasks.Count)
                {
                    tasks[index] += " (Completed)";
                    Console.WriteLine("Task marked as completed!");
                }
                else
                {
                    Console.WriteLine("Invalid task number.");
                }
            }
            Console.WriteLine("\nPress any key to go back...");
            Console.ReadKey();
        }
    }

}

