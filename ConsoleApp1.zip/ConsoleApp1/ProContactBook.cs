﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class ProContactBook
    {

class Contact
    {
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Contact> contacts = new List<Contact>();
            bool exit = false;

            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("Simple Contact Book");
                Console.WriteLine("1. Add Contact");
                Console.WriteLine("2. View Contacts");
                Console.WriteLine("3. Exit");
                Console.Write("Select an option: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddContact(contacts);
                        break;
                    case "2":
                        ViewContacts(contacts);
                        break;
                    case "3":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid option, please try again.");
                        break;
                }
            }
        }

        static void AddContact(List<Contact> contacts)
        {
            Console.Clear();
            Contact contact = new Contact();
            Console.Write("Enter Name: ");
            contact.Name = Console.ReadLine();
            Console.Write("Enter Phone Number: ");
            contact.PhoneNumber = Console.ReadLine();
            Console.Write("Enter Email: ");
            contact.Email = Console.ReadLine();
            contacts.Add(contact);
            Console.WriteLine("Contact added successfully!");
            Console.WriteLine("\nPress any key to go back...");
            Console.ReadKey();
        }

        static void ViewContacts(List<Contact> contacts)
        {
            Console.Clear();
            if (contacts.Count == 0)
            {
                Console.WriteLine("No contacts available.");
            }
            else
            {
                Console.WriteLine("Contacts:");
                foreach (var contact in contacts)
                {
                    Console.WriteLine($"Name: {contact.Name}, Phone: {contact.PhoneNumber}, Email: {contact.Email}");
                }
            }
            Console.WriteLine("\nPress any key to go back...");
            Console.ReadKey();
        }
    }

}
}
