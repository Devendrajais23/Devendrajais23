﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Constants
    {
        public static void Main(string[] args)
        {
            // Declare a constant
            const int dev = 23;
            // Assign a value to the constant
            // dev = 10; // This will cause an error
            // Print the value of the constant
            Console.WriteLine("b " + dev);

            const char de = 'd';
            // de = 'B'; // This will cause an error
            Console.WriteLine("a " + de);
            Console.ReadLine();
        }
    }
}
