﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Loops
    {
        public static void Main(string[]args)

        {     for (int i=1;i<=10;i++)
               
            {
                Console.WriteLine("Iteration:"+i );

            }

            int count = 1;
            while (count <= 10)
            {
                Console.WriteLine("Iteration:" + count);
                count++;
            }
            Console.ReadLine();
        }
    }
}
