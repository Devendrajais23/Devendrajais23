﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{

    /// <summary>
    //Type casting is when you assign a value of one data type to another type.

    //Implicit Casting (automatically) - converting a smaller type to a larger type size
    //char -> int -> long -> float -> double

    //Explicit Casting (manually) - converting a larger type to a smaller size type
    //double -> float -> long -> int -> char

    /// </summary>
    internal class TypeCasting
    {
        static void Main(string[]args)
        { 
            int myInt = 9;          //IMPLICIT CASTING
            double myDouble = myInt;

            double myDouble1 = 9.78;            //EXPLICIT CASTING
            int myInt1 = (int)myDouble1;
            
            //Console.WriteLine(myInt);
            Console.WriteLine(Convert.ToString(myInt));
            //Console.WriteLine(myDouble1);
            Console.WriteLine(Convert.ToString(myDouble1));
            //Console.ReadLine();
            Console.WriteLine("Enter your age: ");              //User Input and Numbers
            int age = Convert.ToInt32( Console.ReadLine());
            Console.WriteLine("Your age is: " + age);
            Console.ReadLine();

        }
    }
}
