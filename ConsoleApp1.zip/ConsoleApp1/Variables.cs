﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Variables
    {
       public static void Main(string[] args)
        {
            // Declare a variable
            int dev;
            // Assign a value to the variable
           dev = 7;
            dev = 10;
            // Print the value of the variable
            Console.WriteLine("b "+ dev);
           

            char de;
            de = 'A';
            Console.WriteLine("a "+ de);
           

            int dj;
            dj = 50;
            Console.WriteLine("c"+ dj);
            Console.ReadLine();


        }
    }
}
